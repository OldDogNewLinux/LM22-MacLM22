#!/bin/bash
#
# This script will gather some things from repositories.
#
# Enjoy!
#
# -Joseph
#
# olddognewlinux@gmail.com
#
#
	ping -c2 google.com >/dev/null
  if [ $? -eq 0 ]; then
 clear
echo
echo
echo "   You have the necessary internet connection."
echo
echo "   This could take a while depending on the speed of your internet connection and computer resource."
echo
	read -p "   Press Enter to continue with the installation, or Ctrl-Z to abort..."
echo
echo
echo "   Please input password to continue..."
echo
echo
#
# Retrieve a few applications to make things nice...
#
# Adding Albert repository...
#
echo 'deb http://download.opensuse.org/repositories/home:/manuelschneid3r/xUbuntu_24.04/ /' | sudo tee /etc/apt/sources.list.d/home:manuelschneid3r.list
curl -fsSL https://download.opensuse.org/repositories/home:manuelschneid3r/xUbuntu_24.04/Release.key | gpg --dearmor | sudo tee /etc/apt/trusted.gpg.d/home_manuelschneid3r.gpg > /dev/null
#
# Adding Fsearch repository...
#
sudo add-apt-repository -y ppa:christian-boxdoerfer/fsearch-stable
#
# Adding Brave Browser repository...
#
sudo curl -fsSLo /usr/share/keyrings/brave-browser-archive-keyring.gpg https://brave-browser-apt-release.s3.brave.com/brave-browser-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/brave-browser-archive-keyring.gpg] https://brave-browser-apt-release.s3.brave.com/ stable main"|sudo tee /etc/apt/sources.list.d/brave-browser-release.list
#
# Adding Google Chrome repository...
#
wget -q -O - https://dl-ssl.google.com/linux/linux_signing_key.pub | sudo apt-key add -
sudo sh -c 'echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/google-chrome.gpg] http://dl.google.com/linux/chrome/deb/ stable main" >> /etc/apt/sources.list.d/google-chrome.list'
#
#
sudo apt update
#
# Remove Transmission-GTK and replace with Transmission-QT... (because it works this way)
#
sudo apt remove --purge -y transmission*
#
# Install applications... (some may already exist)
#
for app in xfce4-goodies xfce4-appmenu* vala-panel-appmenu* xfce4-panel-profiles gnome-system-tools plank gparted hardinfo grub-customizer nemo baobab gnome-system-monitor htop numlockx wavemon gigolo mugshot libcanberra-gtk-module libcanberra-gtk3-module albert fsearch transmission-qt lazpaint-gtk2 google-chrome-stable brave-browser; do sudo apt-get install -y $app; done | tee >> install.log
#
#
echo
echo "								       ***** ALMOST THERE! *****"
echo
#
# Copying modified configuration files to where they belong...
#
sudo chmod -R ugo+rw *
sudo chmod ugo+x decor.sh
sudo cp files/*.desktop /usr/share/applications
sudo cp files/mimeapps.list /usr/share/applications
sudo cp files/autologin-toggle.sh /usr/bin
sudo cp files/slick-greeter.conf /etc/lightdm
sudo cp files/lightdm.conf /etc/lightdm
sudo chmod ugo+rw /usr/bin /usr/share/applications
sudo cp files/52libcanberra-gtk-module_add-to-gtk-modules /etc/X11/Xsession.d
sudo cp files/52appmenu-gtk-module_add-to-gtk-modules /etc/X11/Xsession.d
sudo cp /usr/share/applications/defaults.list /usr/share/applications/defaults.list.BAK
sudo sed -i 's/xed/org.xfce.mousepad/g' /usr/share/applications/defaults.list
sudo cp /usr/share/linuxmint/adjustments/gnome/defaults.list /usr/share/linuxmint/adjustments/gnome/defaults.list.BAK
sudo sed -i 's/xed/org.xfce.mousepad/g' /usr/share/linuxmint/adjustments/gnome/defaults.list
sudo cp /usr/share/applications/xfce4-file-manager.desktop /usr/share/applications/xfce4-file-manager.desktop.BAK
sudo sed -i 's/exo-open --launch FileManager %u/nemo %u/' /usr/share/applications/xfce4-file-manager.desktop
sudo cp /etc/xdg/xfce4/helpers.rc /etc/xdg/xfce4/helpers.rc.BAK
sudo cp .config/xfce4/helpers.rc /etc/xdg/xfce4/helpers.rc
sudo sed -i 's/#autologin-user=/autologin-user='$USER'/' /etc/lightdm/lightdm.conf
sudo chmod ugo+rw /usr/share/applications/*.desktop
sudo chmod ugo+rwx /usr/bin/*.sh
#
# Run the second script...
#
source decor.sh
#
exit
#
	else
 clear
echo
echo "   ********************************************************"
echo "      YOU MUST CONNECT TO THE INTERNET BEFORE CONTINUING."
echo "   ********************************************************"
echo

	fi

	while true; do
  read -p "   Are you ready to connect now? y/n " yn
echo
   case $yn in
	[Yy]* ) nmtui; clear; echo ""; source install.sh; exit;;
        [Nn]* ) clear; echo ""; echo "   Okay. We'll try this again when you're ready."; echo ""; exit;;
        * ) echo "   Please select either Yes or No."; echo
	esac
done
#
